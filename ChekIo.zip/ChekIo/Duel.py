class Warrior():
    health=50
    damage=5
    def heal(health):
        return 50
    def get_damage(health,harm):
        health=health-harm
        return health
    def deal_damage(damage):
        return 5
    pass

class Knight(Warrior):
    def deal_damage(damage):
        return 7    
    pass


def is_alive(unit):
    if unit.heal()>0:
        return True
    else:
        return False
    
def fight(unit_1, unit_2):
    while is_alive(unit_1) and is_alive(unit_2):
        harm=unit_1.deal_damage()
        unit_2.get_damage(unit_2.heal())
        harm=unit_2.deal_damage()
        unit_1.get_damage(unit_1.heal())
        
    if is_alive(unit_1):
        return True
    return False
    

if __name__ == '__main__':
    #These "asserts" using only for self-checking and not necessary for auto-testing

    chuck = Warrior()
    bruce = Warrior()
    carl = Knight()
    dave = Warrior()
    mark = Warrior()

    assert fight(chuck, bruce) == True
    assert fight(dave, carl) == False
    assert chuck.is_alive == True
    assert bruce.is_alive == False
    assert carl.is_alive == True
    assert dave.is_alive == False
    assert fight(carl, mark) == False
    assert carl.is_alive == False

    print("Coding complete? Let's try tests!")