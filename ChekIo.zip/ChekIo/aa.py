def qwqw(line):
    k=0
    a=[]
    if len(line)==0:
        return 0
    else:
        for i in range(1,line+1):
            if line[i]==line[i-1]:
                k=k+1
                m=line[i]
                a.append(str(k)+" "+m)
            if line[i]!=line[i-1]:
                k=0
        return a
line="sdsffffse"
print(qwqw(line))