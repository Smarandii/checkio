def checkio(expression):
    r=0
    bcr=0
    s=0
    bcs=0
    f=0
    bcf=0
    for i in range(len(expression)):
        if expression[i]=="(" and s==0 and f==0:
            print(i)
            r=r+1
            for j in range(len(expression)-1,0,-1):
                if s>0 and expression[j]=="]":
                    return False
                elif f>0 and expression[j]=="}":
                    return False
                elif expression[j]!=")":
                    continue
                else:
                    if expression[j]==")" and bcs==0 and bcf==0:
                        print(j)
                        bcr=bcr+1
                    else:
                        return False
        elif expression[i]=="(" and s==bcs and f==bcf :
            print(i)
            r=r+1
            for j in range(len(expression)-1,0,-1):
                if s<bcs and expression[j]=="]":
                    return False
                elif f<bcf and expression[j]=="}":
                    return False                
                elif expression[j]!=")":
                    continue
                else:
                    if expression[j]==")" and bcs==s and bcf==f:
                        print(j)
                        bcr=bcr+1
                    else:
                        return False
        elif expression[i]=="[" and r==0 and f==0:
            print(i)
            s=s+1
            for j in range(len(expression)-1,0,-1):
                if r>0 and expression[j]==")":
                    return False
                elif f>0 and expression[j]=="}":
                    return False                
                elif expression[j]!="]":
                    continue
                else:
                    if expression[j]=="]" and bcr==0 and bcf==0:
                        print(j)
                        bcs=bcs+1
                    else:
                       
                        return False
        elif expression[i]=="[" and r==bcr and f==bcf:
            print(i)
            s=s+1
            for j in range(len(expression)-1,0,-1):
                if r<bcr and expression[j]==")":
                    return False
                elif f<bcf and expression[j]=="}":
                    return False                    
                elif expression[j]!="]":
                    continue
                else:
                    if expression[j]=="]" and bcr==r and bcf==f:
                        print(j)
                        bcs=bcs+1
                    else:
                        return False
        elif expression[i]=="{" and s==0 and r==0:
            print(i)
            f=f+1
            for j in range(len(expression)-1,0,-1):
                if r>0 and expression[j]==")":
                    return False
                elif s>0 and expression[j]=="]":
                    return False                    
                elif expression[j]!="}":
                    continue                
                else:
                    if expression[j]=="}" and bcr==0 and bcs==0:
                        print(j)
                        bcf=bcf+1
                    else:
                        return False
        elif expression[i]=="{" and s==bcs and r==bcr:
            print(i)
            f=f+1
            for j in range(len(expression)-1,0,-1):
                if r<bcr and expression[j]==")":
                    return False
                elif s<bcs and expression[j]=="]":
                    return False                 
                elif expression[j]!="}":
                    continue
                else:
                    if expression[j]=="}" and bcs==s and bcr==r:
                        print(j)
                        bcf=bcf+1
                    else:
                        return False
    return True
if __name__ == '__main__':
    assert checkio("[1+1]+(2*2)-{3/3}") == True, "Different operators"
    assert checkio("(({[(((1)-2)+3)-3]/3}-3)") == False, "One is redundant"
    assert checkio("2+3") == True, "No brackets, no problem"
        

