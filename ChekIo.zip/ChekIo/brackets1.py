def checkio(expression):
    open1=[]
    close=[]
    close1=[]
    open2=[]
    close2=[]
    r=0
    f=0
    s=0
    for i in expression:
        if i=="(" or i=="[" or i=="{":
            open1.append(i)
        if i==")":
            close.append("(")
        if i=="]":
            close.append("[")
        if i=="}":
            close.append("{")
    if close==open1:
        for i in expression:
            if i=="(":
                open2.append("r")
                r=1
            if i=="[":
                open2.append("s")
                s=1
            if i=="{":
                f=1
                open2.append("f")
            if i==")" and f==0 and s==0:
                r=0
            if i=="]" and r==0 and f==0:
                s=0
            if i=="}" and r==0 and s==0:
                f=0
        if s==0 and r==0 and f==0:
            return True
        else:
            return False
        
    for i in range(len(close)-1,-1,-1):
        print(i)
        close1.append(close[i])
    print(open1,close1)
    return open1==close1

if __name__ == '__main__':
    assert checkio("((5+3)*2+1)") == True, "Simple"
    assert checkio("{[(3+1)+2]+}") == True, "Different types"
    assert checkio("(3+{1-1)}") == False, ") is alone inside {}"
    assert checkio("[1+1]+(2*2)-{3/3}") == True, "Different operators"
    assert checkio("(({[(((1)-2)+3)-3]/3}-3)") == False, "One is redundant"
    assert checkio("2+3") == True, "No brackets, no problem"
    assert checkio("[(3)+(-1)]*{3}") == True, "Open and close in 1 moment"