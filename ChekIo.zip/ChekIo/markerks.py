
def between_markers(text: str, begin: str, end: str) -> str:
    b=0
    e=-1
    o=len(begin)-1
    o1=len(end)-1
    for i in range(len(text)):
        if text[i+o]==begin:
            b=i
        if text[i+e]==end:
            e=i
            break
    return text[b+1:e:]
assert between_markers('What is >apple<', '>', '<') == "apple", "One sym"
assert between_markers("<head><title>My new site</title></head>",
                           "<title>", "</title>") == "My new site", "HTML"
assert between_markers('No[/b] hi', '[b]', '[/b]') == 'No', 'No opened'
assert between_markers('No [b]hi', '[b]', '[/b]') == 'hi', 'No close'
assert between_markers('No hi', '[b]', '[/b]') == 'No hi', 'No markers at all'
assert between_markers('No <hi>', '>', '<') == '', 'Wrong direction'