def checkio(text):
    text=text.lower()
    alpha="abcdefghijklmnopqrstuvwxyz"
    letter=""
    text2=[]
    letters={}
    letters2={}
    key=0
    s=0
    for i in range(len(text)):
        if text[i].isalpha():
            if s<=text.count(text[i]):
                s=text.count(text[i])
                letter=text[i]
                text2.append(letter)
                letters[letter] = s
    print(letters)
    s=0
    for i in range(1,len(text2)+1):
        if letters.get(text2[i-1])>s:
            s=letters.get(text2[i-1])
            mwl=text2[i-1]
        elif letters.get(text2[i-1])==letters.get(text2[i]):
            letters2[text2[i]]=alpha.index(text2[i])
    letters2[text2[0]]=alpha.index(text2[0])
    print(letters2)
    if mwl:
        print(key)
    elif key==0:
        for i in range(1,len(text2)):
            if letters2.get(text2[i-1])>letters.get(text2[i]):
                key1=text2[i]
            if letters2.get(text2[i-1])<letters.get(text2[i]):
                key=text2[i]

                
text="Hello"
print(checkio(text))