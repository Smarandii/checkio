def date_time(time):
    k=0
    hoursstr=" hours "
    minutestr=" minutes "
    for i in range(len(time)):
        if time[i]==".":
            k=k+1
            if k==1:
                data=time[i-2]+time[i-1]
                data=int(data)
            if k==2:
                month=time[i-2]+time[i-1]
                month=int(month)
        if time[i]==":" :
            hours=time[i-2]+time[i-1]
            minutes=time[i+1]+time[i+2]
        if time[i]==" " :
            year=time[i-4]+time[i-3]+time[i-2]+time[i-1]
    if month==1:
        month="January"
    elif month==2:
        month="February"
    elif month==3:
        month="March"
    elif month==4:
        month="April"
    elif month==5:
        month="May"
    elif month==6:
        month="June"
    elif month==7:
        month="July"
    elif month==8:
        month="August"
    elif month==9:
        month="September"
    elif month==10:
        month="October"
    elif month==11:
        month="November"
    elif month==12:
        month=="December"
    if int(hours[0])!=0 or int(minutes[0])!=0:
        hour=hours
        minute=minutes
    if int(hours[0])==0:
        hours=str(hours)
        hour=hours[-1]
        if hour=="1":
            hoursstr=" hour "
    if int(minutes[0])==0:
        minutes=str(minutes)
        minute=minutes[-1]
        if minute=="1":
            minutestr=" minute "
    readable_time=str(data)+" "+month+" "+year+" year "+hour+hoursstr+minute+minutestr
    print(readable_time)
time="01.01.2000 01:01"
date_time(time)
