def checkio(data):
    global s
    global x
    t=len(data)
    x=1
    s=0
    def loa(t):
        global s
        global x
        if t>0:
            s=s+data[t-x]
            x=x+1
            loa(t-x)
        elif t==0:
            return s
    loa(t)
data=[1,2,3]
print(chekio(data))
