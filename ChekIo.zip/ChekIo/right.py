phrases="bleft aleft,ok", "Bright Left"
phrases=str(phrases)
right="right"
a=[]
m=[]
y=[]
s=""
s1=""
for i in range(len(phrases)):
    a.append(phrases[i])
for i in range(len(a)-4):
    if a[i]+a[i+1]+a[i+2]+a[i+3]+a[i+4]=="r"+"i"+"g"+"h"+"t" or a[i]+a[i+1]+a[i+2]+a[i+3]+a[i+4]=="R"+"i"+"g"+"h"+"t" :
        a[i]="l"
        a[i+1]="e"
        a[i+2]="f"
        a[i+3]="t"
        a[i+4]=""
for i in range(len(a)):
    s=s+a[i]
for i in range(len(s)):
    m.append(s[i])
for i in range(len(m)):
    if m[i].isalpha() or m[i]=="," or m[i]==" ":
        if m[i-1]=="," and m[i]==" ":
                m[i]=""
        if m[i]=='"' and m[i+1]==",":
                m[i+1]=""
            s1=s1+m[i]

