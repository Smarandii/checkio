numbers_array=(-1,-2,-3,0)
na=list(numbers_array)
a=[]
b=[]
k=0
for i in range(len(na)):
    a.append(abs(na[i]))
a.sort()
for i in range(len(na)):
    for j in range(len(na)):
        if a[i]==abs(na[j]):
            b.append(na[j])
print(b)
            

            