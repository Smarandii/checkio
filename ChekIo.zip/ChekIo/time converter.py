def time_converter(time):
    t,f=time.split(" ")
    h,m=t.split(":")
    if f=="a.m.":
        if int(h)<=12:
            if int(h)<10:
                h="0"+h
            time=h+":"+m
        time=h+":"+m
        return time
    if f=="p.m.":
        if int(h)>=12 and int(m)>0:
            time=h+":"+m
            return time
        elif int(h)<12:
            h=str(int(h)+12)
            time=h+":"+m
            return time
    
    
time='12:30 p.m.'
time_converter(time)
if __name__ == '__main__':
    assert time_converter('12:30 p.m.') == '12:30'
    assert time_converter('9:00 a.m.') == '09:00'
    assert time_converter('11:15 p.m.') == '23:15'